﻿
// Copyright Christophe Bertrand.

// This allows use of Serializable attributes in DataStructures.cs.

using System;

namespace UniversalSerializerResourceTests
{
	public class SerializableAttribute : Attribute
	{
	}
}