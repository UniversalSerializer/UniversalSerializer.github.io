﻿
// Copyright Christophe Bertrand.

using System;
using UniversalSerializerLib3;

namespace Tester_for_NET_Core
{
	class Program
	{
		static void Main(string[] args)
		{
			Tester.ConsoleTester.Test();
		}
	}
}