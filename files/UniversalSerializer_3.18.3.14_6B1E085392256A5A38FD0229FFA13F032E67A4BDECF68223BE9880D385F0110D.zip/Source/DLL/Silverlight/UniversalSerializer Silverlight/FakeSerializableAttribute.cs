﻿
// Copyright Christophe Bertrand.

using System;

namespace UniversalSerializerResourceTests
{
	public class SerializableAttribute : Attribute
	{
	}
}